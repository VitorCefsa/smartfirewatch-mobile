import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
  SafeAreaView
} from 'react-native';
import { resolveIncident } from '../../api/incidents';

export default function IncidentDetailsScreen({ route, navigation }) {
  const { incident } = route.params;

  const dataHoraObj = new Date(`${incident.data}T${incident.hora}`);
  const dataHoraFormatada = dataHoraObj.toLocaleString('pt-BR');

  const marcarComoResolvido = async () => {
    try {
      await resolveIncident(incident.id);
      Alert.alert('Resolvido', 'Incidente marcado como resolvido.', [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível resolver o incidente.');
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Detalhes do Incidente</Text>
        </View>

        <View style={styles.detailsCard}>
          <DetailRow label="ID:" value={incident.id} />
          <DetailRow label="Status:" value={incident.tipo_incidente} />
          <DetailRow label="Data / Hora:" value={dataHoraFormatada} />
          <DetailRow 
            label="Confiança:" 
            value={incident.confianca != null 
              ? `${(incident.confianca * 100).toFixed(2)}%` 
              : '—'} 
          />
        </View>

        {incident.imagem_base64 ? (
          <View style={styles.imageCard}>
            <Text style={styles.imageLabel}>Imagem capturada:</Text>
            <Image
              source={{ uri: incident.imagem_base64 }}
              style={styles.image}
              resizeMode="cover"
            />
          </View>
        ) : (
          <View style={styles.noImageContainer}>
            <Text style={styles.noImageText}>Imagem não disponível</Text>
          </View>
        )}

        {incident.status !== 'resolvido' && (
          <TouchableOpacity 
            style={styles.resolveButton}
            onPress={marcarComoResolvido}
          >
            <Text style={styles.resolveButtonText}>Marcar como Resolvido</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// Componente auxiliar para linhas de detalhe
const DetailRow = ({ label, value }) => (
  <View style={styles.row}>
    <Text style={styles.label}>{label}</Text>
    <Text style={styles.value}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  container: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    marginBottom: 30,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e1e5e9',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#2d3748',
    textAlign: 'center',
    letterSpacing: 0.3,
  },
  detailsCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 15,
    alignItems: 'flex-start',
  },
  label: {
    fontWeight: '600',
    fontSize: 15,
    width: 100,
    color: '#4a5568',
  },
  value: {
    fontSize: 15,
    color: '#2d3748',
    flex: 1,
    lineHeight: 22,
  },
  imageCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  imageLabel: {
    fontWeight: '600',
    fontSize: 15,
    color: '#4a5568',
    marginBottom: 10,
  },
  image: {
    width: '100%',
    height: 300,
    borderRadius: 8,
  },
  noImageContainer: {
    backgroundColor: '#f8f9fa',
    borderRadius: 12,
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  noImageText: {
    fontStyle: 'italic',
    color: '#a0aec0',
    fontSize: 15,
  },
  resolveButton: {
    backgroundColor: '#38a169',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  resolveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});